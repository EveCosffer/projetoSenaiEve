package br.com.calculadora;

public class Implemento implements Metodos{
	@Override
	public String dividir(double a, double b) {
		// TODO Auto-generated method stub
		return "Resultado: " + (a / b);
	}

	@Override
	public String somar(double a, double b) {
		// TODO Auto-generated method stub
		return "Resultado: " + (a + b);
	}

	@Override
	public String subtrair(double a, double b) {
		// TODO Auto-generated method stub
		return "Resultado: " + (a - b);
	}

	@Override
	public String multiplicar(double a, double b) {
		// TODO Auto-generated method stub
		return "Resultado: " + (a * b); 
	}
}
