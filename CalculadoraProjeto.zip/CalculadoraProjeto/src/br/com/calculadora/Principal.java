package br.com.calculadora;

import javax.swing.JOptionPane;

public class Principal
{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JOptionPane.showMessageDialog(null, 
				"Projeto calculadora, escolha uma op��o e depois escolha os n�meros.");
		
		String numeroUm;
		String numeroDois;
		
		Implemento implemento = new Implemento();
		
		Object[] escolha = {"Somar", "Subtrair", "Dividir", "Multiplicar", "Sair"};
		Object selecaoEscolha;

		do {
			selecaoEscolha = JOptionPane.showInputDialog(null, "Escolha uma op��o:", "Continuar",
					JOptionPane.INFORMATION_MESSAGE, null, escolha, escolha[0]);
			
			if(selecaoEscolha == "Somar") {
				numeroUm = JOptionPane.showInputDialog("Primeiro n�mero:");
				numeroDois = JOptionPane.showInputDialog("Segundo n�mero");
				numeroUm.replace(",", ".");
				numeroDois.replace(",", ".");
				
				
				JOptionPane.showMessageDialog(null, implemento.somar(Double.parseDouble(numeroUm), 
						Double.parseDouble(numeroDois)));
			}
			if(selecaoEscolha == "Subtrair") {
				numeroUm = JOptionPane.showInputDialog("Primeiro n�mero:");
				numeroDois = JOptionPane.showInputDialog("Segundo n�mero");
				numeroUm.replace(",", ".");
				numeroDois.replace(",", ".");
				
				
				JOptionPane.showMessageDialog(null, implemento.subtrair(Double.parseDouble(numeroUm), 
						Double.parseDouble(numeroDois))); 
			}
			if(selecaoEscolha == "Dividir") {
				numeroUm = JOptionPane.showInputDialog("Primeiro n�mero:");
				numeroDois = JOptionPane.showInputDialog("Segundo n�mero");
				numeroUm.replace(",", ".");
				numeroDois.replace(",", ".");
				
				
				JOptionPane.showMessageDialog(null, implemento.dividir(Double.parseDouble(numeroUm),
						Double.parseDouble(numeroDois)));
			}
			if(selecaoEscolha == "Multiplicar") {
				numeroUm = JOptionPane.showInputDialog("Primeiro n�mero:");
				numeroDois = JOptionPane.showInputDialog("Segundo n�mero");
				numeroUm.replace(",", ".");
				numeroDois.replace(",", ".");
				
				
				JOptionPane.showMessageDialog(null, implemento.multiplicar
						(Double.parseDouble(numeroUm), Double.parseDouble(numeroDois)));
			}
			
			if(selecaoEscolha == "Sair") {
				JOptionPane.showMessageDialog(null, "Programa Finalizado! :)");
			}
		} while(selecaoEscolha != "Sair");
		
		
		
		
		
		
		
		
	}
}
