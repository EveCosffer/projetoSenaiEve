package br.com.calculadora;

public interface Metodos{
	public String somar(double a, double b);
	public String subtrair(double a, double b);
	public String dividir(double a, double b);
	public String multiplicar(double a, double b);
	
}
